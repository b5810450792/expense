public class Account {
    private String accname;
    private int accnumber;

    public Account(int accountNumber, String accountName) {
        this.accnumber = accountNumber;
        this.accname = accountName;
    }

    public String getAccname() {
        return accname;
    }

    public void setAccname(String accname) {
        this.accname = accname;
    }

    public int getAccnumber() {
        return accnumber;
    }

    public void setAccnumber(int accnumber) {
        this.accnumber = accnumber;
    }

    @Override
    public String toString() {
        return "Account{" +
                "accname='" + accname + '\'' +
                ", accnumber=" + accnumber +
                '}';
    }
}
